﻿@echo off
chcp 65001 >nul
title 演唱会座位登记 - 网站服务
cd /d "%~dp0web"

where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo [错误] 这台电脑没有安装 Node.js。
  echo 请先到 https://nodejs.org 下载 LTS 版本安装，安装后重新双击本文件。
  echo.
  pause
  exit /b
)

echo 正在启动网站服务，请勿关闭本窗口（关闭即停止网站）...
start "" cmd /c "timeout /t 2 >nul & start http://localhost:3000"
node server.js

echo.
echo 网站服务已停止。按任意键关闭窗口。
pause >nul
